/* Name of package */
/* #undef PACKAGE */

/* Version number of package */
/* #undef VERSION */

/* Define for the x86_64 CPU famyly */
/* #undef X86_64 */
